//let voter = artifacts.require('./contracts/Voter.sol');
let Voter = artifacts.require('./Voter.sol');
contract('Voter',function(accounts)
{
    let voter;
    let firstAccount;

    beforeEach(async function() {
        firstAccount = accounts[0];
        voter = await Voter.new();
        //voter.vote(2);
        await setOptions(firstAccount, [`coffee`, `tea`])
});
//voter = await Voter.new();
//voter.vote(5);
it('Has no votes by default hello' , async function()
{
    let votes = await voter.getVotes.call();

    expect(toNumbers(votes)).to.deep.equal([0,0]);
})
async function setOptions(account, options)
{
        for (pos in options)
    {
        await voter.addOption(options[pos],{from: account});
    } 
    await voter.startVoting({from: account, gas: 6000000});
}
function toNumbers(bigNumbers)
{
    return bigNumbers.map(function(bigNumber)
    {
        return bigNumber.toNumber()
    })
 }

});