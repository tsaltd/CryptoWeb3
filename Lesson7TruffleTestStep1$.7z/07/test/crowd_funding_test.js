let CrowdFundingWithDeadline = artifacts.require('./contracts/CrowdFundingWithDeadline.sol');
const BigNumber = require('bignumber.js')
contract('CrowdFundingWithDeadline', function (accounts) {
    let contract;
    let contractCreator = accounts[0];
    let beneficiary = accounts[1];

    const ONE_ETH = new BigNumber(1000000000000000000);
    let ERROR_MSG = 'Returned error: VM Exception while processing transaction: revert';
    let ONGOING_STATE = 0;
    let FAILED_STATE = 1;
    let SUCCEEDED_STATE = 2;
    let PAID_OUT_STATE = 3;

    beforeEach(async function (){ 
      contract = await CrowdFundingWithDeadline.new('funding',
        1,
        10,
        beneficiary,
        { from: contractCreator, gas: 2000000 });
    });

    it('contract is initialized', async function () {
      let campaignName = await contract.name.call(); 
      expect(campaignName).to.equal('funding');
     // let targetAmount = await (contract.targetAmount.call()).should.be.bignumber.equal(mixed_value)
     // await (contract.functionRetuningInt()).should.be.bignumber.equal(mixed_value);
     // let targetAmount = await  BigNumber(contract.targetAmount.call)();
     let targetAmount = await contract.targetAmount.call()
     expect(ONE_ETH.isEqualTo(targetAmount)).to.equal(true);
      let actualBeneficiry = await contract.beneficiary.call();
      expect(actualBeneficiry).to.equal(beneficiary);
      let state = await contract.state.call()
      expect(state.valueOf().toNumber()).to.equal(ONGOING_STATE)
    });
  });
