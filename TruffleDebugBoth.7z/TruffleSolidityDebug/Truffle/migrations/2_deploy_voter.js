//const Voter = artifacts.require(".\contracts\Voter.sol");
let voter = artifacts.require('./Voter.sol');

module.exports = async function(deployer) {

 //   await deployer.deploy(Voter);
 await   deployer.deploy(voter);

}
